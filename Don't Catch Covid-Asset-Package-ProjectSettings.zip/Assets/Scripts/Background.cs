﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background : MonoBehaviour
{
    [Header("Background Scroll")]
    [SerializeField, Tooltip("Speed of which background will scroll")]
    private float speed; // speed variable for BG movement
    [SerializeField, Tooltip("X dimension for end of background")]
    private float endX; // storage for the 'end' of the x axis once BG needs to switch to second image
    [SerializeField, Tooltip("X dimension for start of background")]
    private float startX; // storage for the 'start' of the x axis once BG needs to start second image

    // Update is called once per frame
    void Update()
    {
        //make vector 2 variable with x coord equal to startx and then set BG position equal to new vector2
        transform.Translate(Vector2.left * speed * Time.deltaTime);

        if (transform.position.x < endX) // if position is less than X of last image
        {
            Vector2 pos = new Vector2(startX, transform.position.y); //change new position to X (no need to change Y axis)
            transform.position = pos; //transform.position now becomes transform.position(X), transform.position.y
        }
    }
}
