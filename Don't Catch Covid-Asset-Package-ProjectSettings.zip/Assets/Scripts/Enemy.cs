﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("Enemy Stats")] // creating controls to configure the enemy within inspector
    [SerializeField, Tooltip("The amount of damage to do the player")]
    private int damage = 1;
    [SerializeField, Tooltip("The speed of the enemy movement")]
    private int speed;

    public GameObject xEffect; //This will be the blood effect when enemy collides with player collision box

    void OnTriggerEnter2D(Collider2D hit) //since we selected ontrigger tag in inspector for enemy, we need to determine what it collided with - or as we've called it hit.
    {
        if (hit.CompareTag("Player")) //here we will use a tag, tagged 'player' gameobject with 'player' so we know the enemy has hit the player.
        {
            Instantiate(xEffect, transform.position, Quaternion.identity); //we initialise the blood effect when player is hit (personal note: before we destory the gameobject)
            SoundManager.soundMgr.PlayOnHitSfx();
            hit.GetComponent<PlayerController>().health -= damage; //we need to get the playercontroller script so we may deduct from the health varaible.
            //Debug.Log(hit.GetComponent<PlayerController>().health); //testing purposes
            Destroy(gameObject); //we need to destory the enemy once it has collided with the player

        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector2.left * speed * Time.deltaTime); // very simple way to move the enemy towards player based on speed variable
    }
}
