﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor;

public class GameOverManager : MonoBehaviour
{
    public string LoadScene = "MainMenu"; //variable for scene load by string
    //Menu Methods
    public void StartGame() //method to load a scene
    {
        SceneManager.LoadScene(LoadScene); // loadscene
    }

    public void RestartGame() // method to restart a scene
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); // reload the same scene
    }
    public void QuitGame() // quit game
    {
        Debug.Log("Quitting Game");
#if UNITY_EDITOR
        EditorApplication.ExitPlaymode();
#endif
        Application.Quit();
    }

}
