﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; //namespace to load and restart scenes
using UnityEditor; // namespace so I can exit out of editor below
using UnityEngine.Audio; // namespace required for audio
using UnityEngine.UI; // namespace required for UI elements

public class MenuManager : MonoBehaviour
{
    public string LoadScene = "IntroScene"; //variable for scene load by string
    public Dropdown resolutionDropdown;
    public Toggle fullscreenToggle;
    public AudioMixer mixer;
    public Slider musicSlider;
    public Toggle musicMuteToggle;
    public Dropdown resolution;
    public Resolution[] resolutions;


    public void Awake()
    {
        LoadPlayerPrefs(); //load settings from playerprefs
    }

    public void Start()
    {
        if (!PlayerPrefs.HasKey("fullscreen")) //check settings from playerprefs
        {
            PlayerPrefs.SetInt("fullscreen", 0);
            Screen.fullScreen = false;
        }
        else
        {
            if (PlayerPrefs.GetInt("fullscreen") == 0)
            {
                Screen.fullScreen = false;
            }
            else
            {
                Screen.fullScreen = true;
            }
        }
        resolutions = Screen.resolutions; //generate screen resolutions to populate options with
        resolution.ClearOptions();
        List<string> options = new List<string>();
        int currentResolutionsIndex = 0;
        for (int i = 0; i < resolutions.Length; i++)
        {
            string option = resolutions[i].width + "x" + resolutions[i].height;
            options.Add(option);
            if(resolutions[i].width == Screen.currentResolution.width && resolutions[i].height == Screen.currentResolution.height)
            {
                currentResolutionsIndex = i;
            }
        }
        resolution.AddOptions(options);
        resolution.value = currentResolutionsIndex;
        resolution.RefreshShownValue();
    }

    //Menu Methods
    public void StartGame() //method to load a scene
    {
        SceneManager.LoadScene(LoadScene); // loadscene
    }


    public void RestartGame() // method to restart a scene
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); // reload the same scene
    }


    public void SetFullScreen(bool fullscreen) //toggle fullscreen
    {
        Screen.fullScreen = fullscreen;
    }

    public void SetResolution(int resolutionIndex)
    {
        Resolution res = resolutions[resolutionIndex];
        Screen.SetResolution(res.width, res.height, Screen.fullScreen);
    }

    public void SetMusicVolume(float value) //music volume
    {
        mixer.SetFloat("MusicVol", value);
    }

    public void ToggleMute(bool isMuted) //music mute
    {
        if (isMuted)
        {
            mixer.SetFloat("Master", -80);
        }
        else
        {
            mixer.SetFloat("Master", 0);
        }
    }


    public void QuitGame() // quit game
    {
        Debug.Log("Quitting Game");
#if UNITY_EDITOR
        EditorApplication.ExitPlaymode();
#endif
        Application.Quit();
    }
    
    public void SavePlayerPrefs() // saving player prefs
    {
        //save quality
        PlayerPrefs.SetInt("quality", QualitySettings.GetQualityLevel());
        //PlayerPrefs.SetInt("quality", qualityDropdown.value);
        //save fullscreen
        if (fullscreenToggle.isOn)
        {
            PlayerPrefs.SetInt("fullscreen", 1);
        }
        else
        {
            PlayerPrefs.SetInt("fullscreen", 0);
        }
        //save audio Sliders
        float musicVol;
        if (mixer.GetFloat("MusicVol", out musicVol))
        {
            PlayerPrefs.SetFloat("MusicVol", musicVol);
        }
        float SFXVol;
        if (mixer.GetFloat("SFXVol", out SFXVol))
        {
            PlayerPrefs.SetFloat("SFXVol", SFXVol);
        }
        PlayerPrefs.Save();
    }

    public void LoadPlayerPrefs()
    {
        //load fullscreen
        if (PlayerPrefs.GetInt("fullscreen") == 0)
        {
            fullscreenToggle.isOn = false;
        }
        else
        {
            fullscreenToggle.isOn = true;
        }

        //load audio Sliders
        float musicVol = PlayerPrefs.GetFloat("MusicVol");
        musicSlider.value = musicVol;
        mixer.SetFloat("MusicVol", musicVol);
        float SFXVol = PlayerPrefs.GetFloat("SFXVol");
        mixer.SetFloat("SFXVol", SFXVol);
    }
}
