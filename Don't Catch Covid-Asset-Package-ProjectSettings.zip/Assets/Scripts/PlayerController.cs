﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; //need to import this namespace for restarting the level - testing purposes - personal note: obsolete
using UnityEngine.UI; //need to import this namespace for health and score HUD

public class PlayerController : MonoBehaviour
{
    #region animation variables
    Animator anim; //passing animator into varaible for later use
    const int STATE_RUN = 0; // constant interget variable to be used for animation states - aligned with Animation controller parameters and conditions
    const int STATE_JUMP = 1; // only have three animations to be concerned with at this stage, run and jump and fly - 0, 1 and 2.
    const int STATE_FLYING = 2; // these intergers are assigned within the animator transitions
    int currentAnimState = STATE_RUN; // storing the default animation state into varaible for later use. 
    //public GameObject jEffect;
    #endregion


    #region player variables
    [Header("Player Stats")] // Header to label the unity inspector accordindly (I want to make it easy for my artist to be able to read and configure inspector).
    public int health = 3; // public varaible here for health so it may be used across the enemy script.
    private Vector2 playerPosition; // player position varaible to store vector, to be used later.
    [Header("Player Lane Control")] // create headers to keep inspector clean and tidy
    [SerializeField, Tooltip("Use to calibrate how far player will move on Y axis during key press")] //Serialize private variables to modify them in inspector and Tooltips as courtesy for artist. 
    private float Yincrease; // don't want to use 'magic' numbers, so we create a variable to store Y axis increase amount which can be set in inspector
    [SerializeField, Tooltip("Use to calibrate speed")]
    private float speed; // create speed variable to control movement speed
    [SerializeField, Tooltip("Use to calibrate maximum amount of lanes up")]
    private float maxHeight; // create maximum and minimum height to disallow player to move off screen
    [SerializeField, Tooltip("Use to calibrate minimum amount of lanes down")]
    private float minHeight; // these variables are what I refer to as the top, middle and bottom lane
    [SerializeField, Tooltip("Use to calibrate the middle lane")]
    private float medHeight; // this will be the middle lane
    [SerializeField, Tooltip("Use to calibrate cooldown time between key press")]
    private float coolDown; // this will hold cool down time inbetween key presses -- not the cleanest option of doing this.
    private float nextMoveTime = 0.0f; // setting default of 0 to make sure buttons can pressed for a first time
    #endregion

    #region hud
    [Header("Player HUD")] //creating fields in inspector for player HUD management
    [SerializeField, Tooltip("For Player Health Display")]
    private Text hudHealth;
    [SerializeField, Tooltip("For Gameover Screen")]
    public GameObject hudGameover;
    #endregion

    // Start is called before the first frame update
    void Start()
    {
        anim = this.GetComponent<Animator>(); //declaring the animator component during initialisation 
    }

    // Update is called once per frame
    void Update()
    {
        hudHealth.text = health.ToString(); // covert health value to string for display on hud - which will just be canvas and panel with text. 

        if (health <= 0) //if player health varaible is less than or equal to zero
        {
            hudGameover.SetActive(true); //set the gameover panel to enable allowing restart script to reload scene
            Destroy(gameObject); //destory player character
            SoundManager.soundMgr.PlayOnDeathSfx(); // call the play on death sound method from sound manager
        }

        //player movement statement
        transform.position = Vector2.MoveTowards(transform.position, playerPosition, speed*Time.deltaTime); //call the MoveTowards function to change our playerPosition varaible according to speed varaible - which is multiplied by delta time to keep things smooth across frames for all PCs

        //player movement controls else/else if statement
        if (Input.GetKeyDown(KeyCode.UpArrow) && transform.position.y < maxHeight && Time.time > nextMoveTime) //transform sprite position 'up' if 'up' arrow is pressed but also ensure that current y position is less than our maxHeight varaible to prevent player moving off screen.
        {
            nextMoveTime = Time.time + coolDown; //delay button press by coolDown variable -- done by passing through current time into nextMoveTime and checking that Time.time is greater than it on next push above.
            MoveUp(); //calling MoveUp function to transform playerpos and play VFX/SFX       
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow) && transform.position.y > minHeight && Time.time > nextMoveTime) //if down arrow is pressed instead (making previous block false) and y position is greater than the 'bottom lane'
        {
            nextMoveTime = Time.time + coolDown; //same as above
            MoveDown();//same as above but calling move down to transform pos negative on y axis
        }

        //animation state changes - if/elseif/else statement
        if (transform.position.y == minHeight || transform.position.y == medHeight) // If player is in bottom lane or player is in medium lane
        {
            changeState(STATE_RUN); //change the state of animation to run
        }
        else if (transform.position.y == maxHeight) //if player is in top lane and player is above medium lane
        {
           changeState(STATE_FLYING); // change the state of animation to fly
        }
        else // if both conditions above return false
        {
            changeState(STATE_JUMP); // change the state of animation to jump --- gives the hop effect
        }

        //movement methods
        void MoveUp()
        {
            playerPosition = new Vector2(transform.position.x, transform.position.y + Yincrease); // store new position inside playerPosition variable, no need to change X position, increase Y position by Yincrease variable.
            //Instantiate(jEffect, transform.position, Quaternion.identity); // spawn jump effect on key press up - no rotation
            SoundManager.soundMgr.PlayOnJumpSfx(); // call the play on jump method from sound manager
        }
        void MoveDown()
        {
            playerPosition = new Vector2(transform.position.x, transform.position.y - Yincrease);  //store new vector into playerPosition - decrease Y position by Yincrease variable - change operator to minus to acheieve this.
            SoundManager.soundMgr.PlayOnLandSfx(); // call the play on land method from sound manager
        }

        //animation state change switch statement
        void changeState(int state) //a method to change animation states as required.
        {
            if (currentAnimState == state) // if default state compared to state
                return; //return switch pass through state
                switch (state) 
            {
                case STATE_RUN: //created switch statement cases for animations 
                    anim.SetInteger("state", STATE_RUN); //change animation to run state
                    break; //must break between cases
                case STATE_JUMP:
                    anim.SetInteger("state", STATE_JUMP); //change animation to jump state
                    break; //as above
                case STATE_FLYING:
                    anim.SetInteger("state", STATE_FLYING); //change animation to fly state
                    break; // and again
            }
            currentAnimState = state; // default state is state
        }

    }
}
