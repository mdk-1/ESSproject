﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreCounter : MonoBehaviour
{
    public int score; // creating score interger varaible to give the runner a more "game" like feel
    public int highscore; // creating highscore interger to keep and display highscore from playerprefers
    public float seconds, minutes; // creating timer float variable to keep time
    public Text hudTime; // need to display time on canvas
    public Text hudDeathTime; // time of player death
    public Text hudScore; // need to display score on canvas
    public Text hudDeathScore; // player score captured on death to display as text on UI
    public Text hudHighScore; // player score captured and returned from playerprefs for display on HUD
    public PlayerController player; //grabbing reference to player script

    private void OnTriggerEnter2D(Collider2D counter) //same method as enemies - create collider on trigger
    {
        if (counter.CompareTag("Enemy")) //detect if what collided is tagged as enemy
        {
            if (player.health > 0) // nested if statement to check if player health is greater than 0 (aka alive)
            {
                score++; //then increase score by 1
                //Debug.Log(score);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        hudScore.text = score.ToString(); // display score on canvas as text -- personal note: updating UI elements in update() is not best practice. Any code here will be called every frame, should not matter with a game this small.
        if (player.health > 0) // if player health greater than 0 (aka player is alive)
        {
            minutes = (int)(Time.timeSinceLevelLoad / 60f); //keep track of minutes
            seconds = (int)(Time.timeSinceLevelLoad % 60f); //keep track of seconds 
            hudTime.text = minutes.ToString("00") + ":" + seconds.ToString("00"); // pass through minutes and seconds into a string so it can be displayed as text on HUD
        }
        if (player.health <= 0) // if player health is less than or equal to 0
        {
            hudDeathScore.text = score.ToString(); // pass through the score at moment health went to 0
            hudDeathTime.text = minutes.ToString("00") + ":" + seconds.ToString("00"); // as well as minutes and seconds - so they may be displayed as text on gameoverHUD
        }
        highscore = (int)score; //highscore variable equals the score variable each frame
        if (PlayerPrefs.GetInt("score") <= highscore) //if the highscore variable is less than the score stored in player prefs
        {
            PlayerPrefs.SetInt("score", highscore); //update this in playerprefs
        }
        hudHighScore.text = PlayerPrefs.GetInt("score").ToString(); // pass through score stored in player prefs to string so be displayed as text on gameoverHUD
        
    }
}
