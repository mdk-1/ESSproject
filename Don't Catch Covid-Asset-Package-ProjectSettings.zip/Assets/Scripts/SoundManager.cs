﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{

    public static SoundManager soundMgr; //declaring sound manager component

    #region Sound Variables
    private AudioSource audioSrc; //creating various array to hold sound files so we may randomly select one below
    private AudioClip[] onHitSfx;
    private AudioClip[] onDeathSfx;
    private AudioClip[] onJumpSfx;
    private AudioClip[] onLandSfx;
    private int rdmOnHitSfx; //creating variables for random index of sound files
    private int rdmOnDeathSfx;
    private int rdmOnJumpSfx;
    private int rdmOnLandSfx;
    #endregion

    // Start is called before the first frame update
    void Start()
    {
        soundMgr = this; //initializing sound manager and loading sound files from resources directory
        audioSrc = GetComponent<AudioSource>();
        onHitSfx = Resources.LoadAll<AudioClip>("onHitSfx");
        onDeathSfx = Resources.LoadAll<AudioClip>("onDeathSfx");
        onJumpSfx = Resources.LoadAll<AudioClip>("onJumpSfx");
        onLandSfx = Resources.LoadAll<AudioClip>("onLandSfx");
    }

    // Methods to call for playing different sounds when required
    public void PlayOnHitSfx()
    {
        rdmOnHitSfx = Random.Range(0, 2); // I have two sounds in folder for this, random range does not include last interger
        audioSrc.PlayOneShot(onHitSfx[rdmOnHitSfx]);
    }
    public void PlayOnJumpSfx()
    {
        rdmOnJumpSfx = Random.Range(0, 2);
        audioSrc.PlayOneShot(onJumpSfx[rdmOnJumpSfx]);
    }
    public void PlayOnLandSfx()
    {
        rdmOnLandSfx = Random.Range(0, 2);
        audioSrc.PlayOneShot(onLandSfx[rdmOnLandSfx]);
    }
    public void PlayOnDeathSfx()
    {
        rdmOnDeathSfx = Random.Range(0, 2);
        audioSrc.PlayOneShot(onDeathSfx[rdmOnDeathSfx]);
    }

}
