﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPoint : MonoBehaviour
{
    public GameObject enemy; //we assign an enemy to spawn from the spawner on start

    // Start is called before the first frame update
    void Start()
    {
        Instantiate(enemy, transform.position, Quaternion.identity); // initialise an enemy to spawn and move towards player without rotating
        //perosonal note: initialise is probably not the correct terminology to use here, but it helps me remember what Instantiate does.
    }

}
