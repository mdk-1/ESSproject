﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject[] enemylane; //create an array to hold serveral different spawn patterns to give the game some challange.

    [Header("Spawn Control")] //controls to tweak the spawning system in inspector
    [SerializeField]
    private float timeBetweenSpawn; // variable to hold time between waves
    [SerializeField]
    private float startTimeBetweenSpawn; // need this to hold a start time
    [SerializeField]
    private float decreaseTimeBetweenSpawn; // need this to decrease the time between waves
    [SerializeField]
    private float minSpawnTime; // control to keep time

    // Start is called before the first frame update
    void Start()
    {
        timeBetweenSpawn = startTimeBetweenSpawn; // on start store timebetweenspawn into starttimebetweenspawn
    }

    // Update is called once per frame
    void Update()
    {
        if (timeBetweenSpawn <= 0) // if we have nothing spawned
        {
            int randomlane = Random.Range(0, enemylane.Length); // we use the random function against our enemylane array to randomly select a pattern to spawn
            Instantiate(enemylane[randomlane], transform.position, Quaternion.identity); // we intialise the random enemy spawn and move towards player without any rotation
            timeBetweenSpawn = startTimeBetweenSpawn; // we will pass timeBetweenSpawn back into the start varaible so it will have to wait X amount of seconds before another spawn
            if (startTimeBetweenSpawn > minSpawnTime) //if start time is greater than minspawntime
            {
                startTimeBetweenSpawn -= decreaseTimeBetweenSpawn; // starttime should minus or equal to decreasetime time
            }
            
        }
        else
        {
            timeBetweenSpawn -= Time.deltaTime; // if the above statement is false, decrease the time between waves
        }
    }
}
